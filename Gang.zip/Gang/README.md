# sistds06
Pequeno Sistema de Vendas, desenvolvido com classes usando a programação C#, com o framework do WindowsForms, em conjunto com a turma TDS06 - 2022.
